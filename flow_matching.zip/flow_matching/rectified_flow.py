import torch
import torch.nn.functional as F


class RectifiedFlow:
    def __init__(self, sigma_min=0.):
        self.sigma_min = sigma_min

    def interpolate(self, x_0, x_1, t):
        t = t.view(-1, 1, 1, 1)
        return (1 - (1 - self.sigma_min) * t) * x_0 + t * x_1

    def euler(self, x_t, v, dt):
        x_t = x_t + v * dt
        return x_t

    def mse_loss(self, v, x_0, x_1):
        loss = F.mse_loss(x_1 - (1 - self.sigma_min) * x_0, v)
        return loss

    def sample(self, model, t_steps, shape, DEVICE, label=7.):
        """
            move x_0 (located in noise distribution) to x_1 (located in target data distribution)
        """
        x_0 = torch.randn(size=shape, device=DEVICE)
        ts = torch.linspace(0, 1, t_steps, device=DEVICE)
        labels = torch.tensor(label, device=DEVICE).repeat(shape[0])
        dt = 1.0 / (t_steps - 1)

        x_t = x_0
        for i in range(t_steps - 1):
            t = ts[i]
            v = model(x_t, t, labels).sample  # return UNet2DOutput(sample=sample)
            x_t = self.euler(x_t, v, dt)
        return x_t
