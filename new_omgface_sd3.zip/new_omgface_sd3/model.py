import os
import torch
from diffusers import (
    FlowMatchEulerDiscreteScheduler,
    AutoencoderKL,
    SD3Transformer2DModel,
    FlowMatchEulerDiscreteScheduler,
)
from peft import PeftModel, LoraConfig
from diffusers.training_utils import (
    free_memory,
)


def encode_images(pixels: torch.Tensor, vae: torch.nn.Module, weight_dtype):
    pixel_latents = vae.encode(pixels.to(vae.dtype)).latent_dist.sample()
    pixel_latents = (
        pixel_latents - vae.config.shift_factor
    ) * vae.config.scaling_factor
    return pixel_latents.to(weight_dtype)


def set_transformer_lora(transformer, rank, lora_alpha):
    target_modules = [
        "attn.add_k_proj",
        "attn.add_q_proj",
        "attn.add_v_proj",
        "attn.to_add_out",
        "attn.to_k",
        "attn.to_out.0",
        "attn.to_q",
        "attn.to_v",
    ]

    # now we will add new LoRA weights to the attention layers
    transformer_lora_config = LoraConfig(
        r=rank,
        init_lora_weights="gaussian",
        target_modules=target_modules,
    )
    transformer = PeftModel(
        model=transformer,
        peft_config=transformer_lora_config,
        adapter_name="sd_lora_adapter",
    )
    transformer.print_trainable_parameters()
    return transformer


def set_vae_encoder_lora(vae_encoder, rank, lora_alpha):
    target_modules = [
        "conv1",
        "conv2",
        "conv_in",
        "conv_shortcut",
        "conv",
        "conv_out",
        "to_k",
        "to_q",
        "to_v",
        "to_out.0",
    ]

    # now we will add new LoRA weights to the attention layers
    vae_encoder_lora_config = LoraConfig(
        r=rank,
        init_lora_weights="gaussian",
        target_modules=target_modules,
    )
    vae_encoder = PeftModel(
        model=vae_encoder,
        peft_config=vae_encoder_lora_config,
        adapter_name="vae_encoder_lora_adapter",
    )
    vae_encoder.print_trainable_parameters()
    return vae_encoder


class OMGFaceSD3Medium(torch.nn.Module):
    def __init__(
        self,
        pretrained_model_name_or_path,
        rank,
        device,
        weight_dtype=torch.bfloat16,
        mid_timestep=295,
    ):
        super().__init__()

        # load fix vae
        self.fix_vae = AutoencoderKL.from_pretrained(
            pretrained_model_name_or_path, subfolder="vae"
        )

        # load lora vae encoder
        self.lora_vae = AutoencoderKL.from_pretrained(
            pretrained_model_name_or_path, subfolder="vae"
        )

        # del decoder
        del self.lora_vae.decoder
        free_memory()

        # load transformer
        self.transformer = SD3Transformer2DModel.from_pretrained(
            pretrained_model_name_or_path, subfolder="transformer"
        )

        self.fix_vae.requires_grad_(False)
        self.transformer.requires_grad_(False)

        self.fix_vae = self.fix_vae.to(device, dtype=torch.float32)
        self.lora_vae = self.lora_vae.to(device, dtype=torch.float32)
        self.transformer = self.transformer.to(device, dtype=weight_dtype)

        self.lora_vae.encoder = set_vae_encoder_lora(self.lora_vae.encoder, rank)
        self.transformer = set_transformer_lora(self.transformer, rank)

        # Load scheduler
        self.noise_scheduler = FlowMatchEulerDiscreteScheduler(
            num_train_timesteps=1000, shift=3.0
        )
        self.t = self.noise_scheduler.timesteps[-mid_timestep]
        self.sigma = self.noise_scheduler.sigmas[-mid_timestep]
        print(f"Timestep: {self.t} -> 0.0")
        print(f"Sigma: {self.sigma}")

    def forward(
        self,
        lq_latent,
        prompt_embeds,
        pooled_prompt_embeds,
        weight_dtype=torch.bfloat16,
    ):

        model_pred = self.transformer(
            hidden_states=lq_latent,
            timestep=torch.tensor([self.t]).to(lq_latent.device, dtype=weight_dtype),
            encoder_hidden_states=prompt_embeds,
            pooled_projections=pooled_prompt_embeds,
            return_dict=False,
        )[0]

        lq_latent = lq_latent - self.sigma * model_pred

        lq_latent = (
            lq_latent / self.fix_vae.config.scaling_factor
        ) + self.fix_vae.config.shift_factor

        pred_img = self.fix_vae.decode(
            lq_latent.to(self.fix_vae.dtype), return_dict=False
        )[0]
        return pred_img


class SD3OneStepModelInf(torch.nn.Module):
    def __init__(
        self,
        sd_path,
        lora_path,
        device,
        weight_dtype=torch.bfloat16,
        mid_timestep=295,
    ):
        super().__init__()

        self.vae = AutoencoderKL.from_pretrained(sd_path, subfolder="vae")

        # load transformer
        self.transformer = SD3Transformer2DModel.from_pretrained(
            sd_path, subfolder="transformer"
        )

        self.vae.requires_grad_(False)
        self.transformer.requires_grad_(False)

        self.transformer = PeftModel.from_pretrained(
            self.transformer,
            os.path.join(lora_path, "sd_lora_adapter"),
            adapter_name="sd_lora_adapter",
        )
        self.vae.encoder = PeftModel.from_pretrained(
            self.vae.encoder,
            os.path.join(lora_path, "vae_encoder_lora_adapter"),
            adapter_name="vae_encoder_lora_adapter",
        )

        self.vae = self.vae.to(device, dtype=torch.float32)
        self.transformer = self.transformer.to(device, dtype=weight_dtype)

        # Load scheduler
        self.noise_scheduler = FlowMatchEulerDiscreteScheduler(
            num_train_timesteps=1000, shift=3.0
        )
        self.t = self.noise_scheduler.timesteps[-mid_timestep]
        self.sigma = self.noise_scheduler.sigmas[-mid_timestep]
        print(f"Timestep: {self.t} -> 0.0")
        print(f"Sigma: {self.sigma}")

    def forward(
        self,
        hq_img,
        prompt_embeds,
        pooled_prompt_embeds,
        weight_dtype=torch.bfloat16,
    ):
        lq_latent = encode_images(hq_img, self.vae, weight_dtype)
        model_pred = self.transformer(
            hidden_states=lq_latent,
            timestep=torch.tensor([self.t]).to(lq_latent.device, dtype=weight_dtype),
            encoder_hidden_states=prompt_embeds,
            pooled_projections=pooled_prompt_embeds,
            return_dict=False,
        )[0]

        lq_latent = lq_latent - self.sigma * model_pred

        lq_latent = (
            lq_latent / self.vae.config.scaling_factor
        ) + self.vae.config.shift_factor

        pred_img = self.vae.decode(lq_latent.to(self.vae.dtype), return_dict=False)[0]
        return pred_img
