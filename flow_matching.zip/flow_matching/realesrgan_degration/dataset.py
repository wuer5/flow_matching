import os

import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms
from torchvision.utils import save_image


class PairedImageDataset(Dataset):
    def __init__(self, hq_dir, lq_dir, transform=None):
        self.hq_dir = hq_dir
        self.lq_dir = lq_dir
        self.transform = transform

        # 假设两个文件夹结构完全一致，直接遍历其中一个文件夹即可
        self.hq_files = []
        for root, _, files in os.walk(hq_dir):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    rel_path = os.path.relpath(root, hq_dir)
                    self.hq_files.append((rel_path, file))

    def __len__(self):
        return len(self.hq_files)

    def __getitem__(self, idx):
        rel_path, file = self.hq_files[idx]

        # 构建对应路径
        hq_path = os.path.join(self.hq_dir, rel_path, file)
        lq_path = os.path.join(self.lq_dir, f'lq_{rel_path}', file)

        # 读取图片
        hq_img = Image.open(hq_path).convert('RGB')
        lq_img = Image.open(lq_path).convert('RGB')

        if self.transform:
            hq_img = self.transform(hq_img)
            lq_img = self.transform(lq_img)

        return hq_img, lq_img


if __name__ == '__main__':
    hq_dir = './ffhq-64x64'  # 替换为ffhq文件夹路径
    lq_dir = './ffhq-64x64-lq'  # 替换为ffhq-lq文件夹路径
    transform = transforms.Compose([
        transforms.ToTensor(),  # 转换为Tensor
        transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])  # 归一化
    ])
    dataset = PairedImageDataset(hq_dir, lq_dir, transform=transform)
    dataloader = torch.utils.data.DataLoader(
        dataset,
        batch_size=32,
        shuffle=True,
        num_workers=4
    )
    batch = next(iter(dataloader))
    hq_images = batch[0]  # 高清图片
    lq_images = batch[1]  # 低清图片
    save_image(hq_images, 'hq_images.jpg', nrow=8)
    save_image(lq_images, 'lq_images.jpg', nrow=8)
