import argparse
import os

import numpy as np
import torch
from PIL import Image
from torch.optim import Adam
from torch.utils.data import DataLoader, Dataset
from torchvision.transforms import transforms
from tqdm import tqdm


def parse_args():
    parser = argparse.ArgumentParser(description="Rectified Flow Training Script")

    # 数据集参数
    parser.add_argument("--dataset", type=str, default="MNIST", choices=["CIFAR10", "MNIST"],
                        help="Dataset to use CIFAR10 or MNIST")
    parser.add_argument("--dataset_path", type=str, default="/home/jianghaoyan/code/cfm/datasets",
                        help="Path to dataset directory")

    # 训练参数
    parser.add_argument("--n_epochs", type=int, default=200,
                        help="Number of training epochs")
    parser.add_argument("--train_batch_size", type=int, default=128,
                        help="Training batch size")
    parser.add_argument("--inference_batch_size", type=int, default=64,
                        help="Inference batch size")
    parser.add_argument("--lr", type=float, default=5e-5,
                        help="Learning rate")
    parser.add_argument("--sigma_min", type=float, default=0,
                        help="Minimum sigma value")

    # 设备参数
    parser.add_argument("--gpu_id", type=int, default=0,
                        help="GPU ID to use")
    parser.add_argument("--no_cuda", action="store_true",
                        help="Disable CUDA (use CPU instead)")

    # 随机种子
    parser.add_argument("--seed", type=int, default=1234,
                        help="Random seed")

    return parser.parse_args()


class PairedImageDataset(Dataset):
    def __init__(self, hq_dir, lq_dir, transform=None):
        self.hq_dir = hq_dir
        self.lq_dir = lq_dir
        self.transform = transform

        # 假设两个文件夹结构完全一致，直接遍历其中一个文件夹即可
        self.hq_files = []
        for root, _, files in os.walk(hq_dir):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    rel_path = os.path.relpath(root, hq_dir)
                    self.hq_files.append((rel_path, file))

    def __len__(self):
        return len(self.hq_files)

    def __getitem__(self, idx):
        rel_path, file = self.hq_files[idx]

        # 构建对应路径
        hq_path = os.path.join(self.hq_dir, rel_path, file)
        lq_path = os.path.join(self.lq_dir, f'lq_{rel_path}', file)

        # 读取图片
        hq_img = Image.open(hq_path).convert('RGB')
        lq_img = Image.open(lq_path).convert('RGB')

        if self.transform:
            hq_img = self.transform(hq_img)
            lq_img = self.transform(lq_img)

        return hq_img, lq_img


def main():
    args = parse_args()

    # transform = transforms.Compose([
    #     transforms.ToTensor(),
    # ])

    cuda = not args.no_cuda and torch.cuda.is_available()
    DEVICE = torch.device(f"cuda:{args.gpu_id}" if cuda else "cpu")

    # im_size = (3, 32, 32) if args.dataset == "CIFAR10" else (1, 28, 28)
    im_size = (3, 64, 64)

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    # if args.dataset == 'CIFAR10':
    #     train_dataset = CIFAR10(args.dataset_path, transform=transform, train=True, download=True)
    # else:
    #     train_dataset = MNIST(args.dataset_path, transform=transform, train=True, download=True)

    # train_loader = DataLoader(dataset=train_dataset, batch_size=args.train_batch_size, shuffle=True)
    hq_dir = '/home/jianghaoyan/code/datasets/ffhq-64x64'
    lq_dir = '/home/jianghaoyan/code/datasets/ffhq-64x64-lq'
    transform = transforms.Compose([
        transforms.ToTensor(),  # 转换为Tensor
        transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])  # 归一化
    ])
    dataset = PairedImageDataset(hq_dir, lq_dir, transform=transform)
    train_loader = DataLoader(
        dataset,
        batch_size=args.train_batch_size,
        shuffle=True,
        num_workers=4
    )

    from model import get_unet_model
    from rectified_flow import RectifiedFlow

    model = get_unet_model(img_size=im_size[1], in_channels=im_size[0]).to(DEVICE)
    rf = RectifiedFlow()
    optimizer = Adam(model.parameters(), lr=args.lr)

    print("Start training CFM...")
    model.train()
    best_loss = float('inf')

    for epoch in range(args.n_epochs):
        total_loss = 0
        for batch_idx, (x_1, x_0) in enumerate(tqdm(train_loader, ncols=100)):
            optimizer.zero_grad()

            x_1 = x_1.to(DEVICE)
            x_0 = x_0.to(DEVICE)
            # x_0 = torch.randn_like(x_1)
            t = torch.rand(x_1.shape[0], device=DEVICE)

            x_t = rf.interpolate(x_0, x_1, t)
            v_pred = model(x_t, t).sample  # return UNet2DOutput(sample=sample)

            loss = rf.mse_loss(v_pred, x_0, x_1)
            total_loss += loss.item()

            loss.backward()
            optimizer.step()

        epoch_loss = total_loss / len(train_loader)
        print("\tEpoch", epoch + 1, "complete!", "\tCFM Loss: ", epoch_loss)
        # Saved best model
        if epoch_loss < best_loss:
            best_loss = epoch_loss
            torch.save({
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'best_loss': best_loss,
                'epoch': epoch
            }, 'best_model.pth')
            print(f"New best model saved with loss: {best_loss:.4f}")
    print("Finish!!")


if __name__ == "__main__":
    main()
