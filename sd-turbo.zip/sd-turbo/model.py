import torch
from diffusers import AutoencoderKL, UNet2DConditionModel, DDPMScheduler
from peft import LoraConfig, PeftModel
from transformers import AutoTokenizer, CLIPTextModel
import copy
from diffusers.training_utils import free_memory


def set_unet_lora(unet, rank):
    target_modules = [
        "conv1",
        "conv2",
        "conv_in",
        "conv_shortcut",
        "conv",
        "conv_out",
        "to_k",
        "to_q",
        "to_v",
        "to_out.0",
    ]

    # now we will add new LoRA weights to the attention layers
    unet_lora_config = LoraConfig(
        r=rank,
        target_modules=target_modules,
        init_lora_weights="gaussian",
    )
    unet = PeftModel(
        model=unet,
        peft_config=unet_lora_config,
        adapter_name="unet_lora_adapter",
    )
    unet.print_trainable_parameters()
    return unet


class OneModel(torch.nn.Module):
    def __init__(self, sd_path, vae, timestep, unet_rank, device):
        super().__init__()
        self.vae = vae
        self.timestep = timestep
        self.scheduler = DDPMScheduler.from_pretrained(sd_path, subfolder="scheduler")
        self.alpha_t = self.scheduler.alphas_cumprod[timestep]
        unet = UNet2DConditionModel.from_pretrained(sd_path, subfolder="unet")
        unet.requires_grad_(False)
        unet = set_unet_lora(unet, unet_rank)
        self.unet = unet
        self.device = device
        print(
            f"Timestep: {timestep}, (1 - self.alpha_t).sqrt(): {(1 - self.alpha_t).sqrt()}, self.alpha_t.sqrt(): {self.alpha_t.sqrt()}"
        )

    def forward(self, lq_latent, prompt_embeds):
        model_pred = self.unet(
            lq_latent,
            self.timestep,
            encoder_hidden_states=prompt_embeds,
        ).sample
        denoised_latent = (
            lq_latent - (1 - self.alpha_t).sqrt() * model_pred
        ) / self.alpha_t.sqrt()
        pred_img = (
            self.vae.decode(denoised_latent / self.vae.config.scaling_factor).sample
        ).clamp(-1, 1)
        return pred_img
