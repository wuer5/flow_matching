#!/usr/bin/env python
# coding=utf-8
# Copyright 2025 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and

import argparse
import logging
import math
import os
from pathlib import Path
from omegaconf import OmegaConf
import torch
import transformers
from accelerate import Accelerator, DistributedType
from accelerate.logging import get_logger
from accelerate.utils import (
    ProjectConfiguration,
    set_seed,
)
from tqdm.auto import tqdm
from transformers import PretrainedConfig
from torchvision.utils import save_image
import diffusers
from diffusers import (
    StableDiffusion3Pipeline,
)
from diffusers.optimization import get_scheduler
from diffusers.training_utils import (
    free_memory,
)
from diffusers.utils.torch_utils import is_compiled_module
import torch.nn.functional as F
import warnings
from dataloaders.my_dataset import PairedDataset, degradation_proc
from diffusers.utils.import_utils import is_xformers_available
from patch_util import image_to_patches_fold

warnings.filterwarnings("ignore")


logger = get_logger(__name__)


def load_text_encoders(class_one, class_two, class_three, args):
    text_encoder_one = class_one.from_pretrained(
        args.pretrained_model_name_or_path,
        subfolder="text_encoder",
        revision=args.revision,
        variant=args.variant,
    )
    text_encoder_two = class_two.from_pretrained(
        args.pretrained_model_name_or_path,
        subfolder="text_encoder_2",
        revision=args.revision,
        variant=args.variant,
    )
    text_encoder_three = class_three.from_pretrained(
        args.pretrained_model_name_or_path,
        subfolder="text_encoder_3",
        revision=args.revision,
        variant=args.variant,
    )
    return text_encoder_one, text_encoder_two, text_encoder_three


def import_model_class_from_model_name_or_path(
    pretrained_model_name_or_path: str, revision: str, subfolder: str = "text_encoder"
):
    text_encoder_config = PretrainedConfig.from_pretrained(
        pretrained_model_name_or_path, subfolder=subfolder, revision=revision
    )
    model_class = text_encoder_config.architectures[0]
    if model_class == "CLIPTextModelWithProjection":
        from transformers import CLIPTextModelWithProjection

        return CLIPTextModelWithProjection
    elif model_class == "T5EncoderModel":
        from transformers import T5EncoderModel

        return T5EncoderModel
    else:
        raise ValueError(f"{model_class} is not supported.")


def parse_args():
    parser = argparse.ArgumentParser(description="Simple example of a training script.")
    parser.add_argument(
        "--config",
        type=str,
        default="cfg.yml",
        help="path to config",
    )
    args = parser.parse_args()

    return args.config


def encode_images(pixels: torch.Tensor, vae: torch.nn.Module, weight_dtype):
    pixel_latents = vae.encode(pixels.to(vae.dtype)).latent_dist.sample()
    pixel_latents = (
        pixel_latents - vae.config.shift_factor
    ) * vae.config.scaling_factor
    return pixel_latents.to(weight_dtype)


def main():
    args = OmegaConf.load(parse_args())
    config = OmegaConf.load(args.degra_cfg)
    logging_dir = Path(args.output_dir, args.logging_dir)

    accelerator_project_config = ProjectConfiguration(
        project_dir=args.output_dir, logging_dir=logging_dir
    )
    accelerator = Accelerator(
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        mixed_precision=args.mixed_precision,
        project_config=accelerator_project_config,
    )

    # Disable AMP for MPS.
    if torch.backends.mps.is_available():
        accelerator.native_amp = False

    # Make one log on every process with the configuration for debugging.
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO,
    )
    logger.info(accelerator.state, main_process_only=False)
    if accelerator.is_local_main_process:
        transformers.utils.logging.set_verbosity_warning()
        diffusers.utils.logging.set_verbosity_info()
    else:
        transformers.utils.logging.set_verbosity_error()
        diffusers.utils.logging.set_verbosity_error()

    # If passed along, set the training seed now.
    if args.seed is not None:
        set_seed(args.seed)

    # Handle the repository creation
    if accelerator.is_main_process:
        if args.output_dir is not None:
            os.makedirs(args.output_dir, exist_ok=True)
            OmegaConf.save(args, os.path.join(args.output_dir, "cfg.yml"))

    # For mixed precision training we cast all non-trainable weights (vae, non-lora text_encoder and non-lora transformer) to half-precision
    # as these weights are only used for inference, keeping weights in full precision is not required.
    weight_dtype = torch.float32
    if accelerator.mixed_precision == "fp16":
        weight_dtype = torch.float16
    elif accelerator.mixed_precision == "bf16":
        weight_dtype = torch.bfloat16

    if not args.fixed_prompt_embeds:
        # Load the tokenizers
        text_pipe = StableDiffusion3Pipeline.from_pretrained(
            args.pretrained_model_name_or_path,
            vae=None,
            transformer=None,
            torch_dtype=torch.bfloat16,
        ).to(accelerator.device)
        (
            prompt_embeds,
            _,
            pooled_prompt_embeds,
            _,
        ) = text_pipe.encode_prompt(
            prompt=args.instance_prompt, prompt_2=None, prompt_3=None
        )
        del text_pipe
        free_memory()
        torch.save(
            {
                "prompt_embeds": prompt_embeds,
                "pooled_prompt_embeds": pooled_prompt_embeds,
            },
            "sd3.5_prompt_embedds.pt",
        )
    else:
        prompts = torch.load(
            args.fixed_prompt_embeds, map_location=accelerator.device, weights_only=True
        )
        prompt_embeds, pooled_prompt_embeds = (
            prompts["prompt_embeds"],
            prompts["pooled_prompt_embeds"],
        )

    from model import SD3OneStepModel

    net_sr = SD3OneStepModel(
        args.pretrained_model_name_or_path,
        args.rank,
        args.lora_alpha,
        accelerator.device,
        weight_dtype,
        args.mid_timestep,
    )

    if args.enable_xformers_memory_efficient_attention:
        if is_xformers_available():
            net_sr.transformer.enable_xformers_memory_efficient_attention()
        else:
            raise ValueError(
                "xformers is not available, please install it by running `pip install xformers`"
            )

    import vision_aided_loss

    net_disc = vision_aided_loss.Discriminator(
        cv_type="dino",
        output_type="conv_multi_level",
        loss_type=args.gan_loss_type,
        device="cuda",
    )
    import lpips

    net_lpips = lpips.LPIPS(net="vgg").to(accelerator.device)
    net_lpips.requires_grad_(False)

    net_disc = net_disc.to(accelerator.device)
    net_disc.requires_grad_(True)
    net_disc.cv_ensemble.requires_grad_(False)

    if args.gradient_checkpointing:
        net_sr.transformer.enable_gradient_checkpointing()

    def unwrap_model(model):
        model = accelerator.unwrap_model(model)
        model = model._orig_mod if is_compiled_module(model) else model
        return model

    # Enable TF32 for faster training on Ampere GPUs,
    # cf https://pytorch.org/docs/stable/notes/cuda.html#tensorfloat-32-tf32-on-ampere-devices
    if args.allow_tf32 and torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True

    logger.info(
        f"Total net_sr training parameters: {sum([p.numel() for p in net_sr.parameters() if p.requires_grad]) / 1000000} M"
    )
    logger.info(
        f"Total net_disc training parameters: {sum([p.numel() for p in net_disc.parameters() if p.requires_grad]) / 1000000} M"
    )
    net_sr_to_optimize = list(filter(lambda p: p.requires_grad, net_sr.parameters()))

    if args.use_8bit_adam:
        try:
            import bitsandbytes as bnb
        except ImportError:
            raise ImportError(
                "To use 8-bit Adam, please install the bitsandbytes library: `pip install bitsandbytes`."
            )

        optimizer_class = bnb.optim.AdamW8bit
    else:
        optimizer_class = torch.optim.AdamW

    optimizer = optimizer_class(
        net_sr_to_optimize,
        lr=args.learning_rate,
        betas=(args.adam_beta1, args.adam_beta2),
        weight_decay=args.adam_weight_decay,
        eps=args.adam_epsilon,
    )

    optimizer_disc = optimizer_class(
        net_disc.parameters(),
        lr=args.learning_rate,
        betas=(args.adam_beta1, args.adam_beta2),
        weight_decay=args.adam_weight_decay,
        eps=args.adam_epsilon,
    )

    train_dataset = PairedDataset(config.train)
    train_dataloader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=args.train_batch_size,
        shuffle=True,
        num_workers=args.dataloader_num_workers,
    )

    # Scheduler and math around the number of training steps.
    overrode_max_train_steps = False
    num_update_steps_per_epoch = math.ceil(
        len(train_dataloader) / args.gradient_accumulation_steps
    )
    if args.max_train_steps is None:
        args.max_train_steps = args.num_train_epochs * num_update_steps_per_epoch
        overrode_max_train_steps = True

    lr_scheduler = get_scheduler(
        args.lr_scheduler,
        optimizer=optimizer,
        num_warmup_steps=args.lr_warmup_steps * accelerator.num_processes,
        num_training_steps=args.max_train_steps * accelerator.num_processes,
        num_cycles=args.lr_num_cycles,
        power=args.lr_power,
    )

    lr_scheduler_disc = get_scheduler(
        args.lr_scheduler,
        optimizer=optimizer,
        num_warmup_steps=args.lr_warmup_steps * accelerator.num_processes,
        num_training_steps=args.max_train_steps * accelerator.num_processes,
        num_cycles=args.lr_num_cycles,
        power=args.lr_power,
    )

    (
        net_sr,
        net_disc,
        optimizer,
        optimizer_disc,
        train_dataloader,
        lr_scheduler,
        lr_scheduler_disc,
    ) = accelerator.prepare(
        net_sr,
        net_disc,
        optimizer,
        optimizer_disc,
        train_dataloader,
        lr_scheduler,
        lr_scheduler_disc,
    )

    # We need to recalculate our total training steps as the size of the training dataloader may have changed.
    num_update_steps_per_epoch = math.ceil(
        len(train_dataloader) / args.gradient_accumulation_steps
    )
    if overrode_max_train_steps:
        args.max_train_steps = args.num_train_epochs * num_update_steps_per_epoch
    # Afterwards we recalculate our number of training epochs
    args.num_train_epochs = math.ceil(args.max_train_steps / num_update_steps_per_epoch)

    # Train!
    total_batch_size = (
        args.train_batch_size
        * accelerator.num_processes
        * args.gradient_accumulation_steps
    )

    logger.info("***** Running training *****")
    logger.info(f"  Num examples = {len(train_dataset)}")
    logger.info(f"  Num batches each epoch = {len(train_dataloader)}")
    logger.info(f"  Num Epochs = {args.num_train_epochs}")
    logger.info(f"  Instantaneous batch size per device = {args.train_batch_size}")
    logger.info(
        f"  Total train batch size (w. parallel, distributed & accumulation) = {total_batch_size}"
    )
    logger.info(f"  Gradient Accumulation steps = {args.gradient_accumulation_steps}")
    logger.info(f"  Total optimization steps = {args.max_train_steps}")
    global_step = 0
    first_epoch = 0

    # Potentially load in the weights and states from a previous save
    if args.resume_from_checkpoint:
        if args.resume_from_checkpoint != "latest":
            path = os.path.basename(args.resume_from_checkpoint)
        else:
            # Get the mos recent checkpoint
            dirs = os.listdir(args.output_dir)
            dirs = [d for d in dirs if d.startswith("checkpoint")]
            dirs = sorted(dirs, key=lambda x: int(x.split("-")[1]))
            path = dirs[-1] if len(dirs) > 0 else None

        if path is None:
            accelerator.print(
                f"Checkpoint '{args.resume_from_checkpoint}' does not exist. Starting a new training run."
            )
            args.resume_from_checkpoint = None
            initial_global_step = 0
        else:
            accelerator.print(f"Resuming from checkpoint {path}")
            accelerator.load_state(os.path.join(args.output_dir, path))
            global_step = int(path.split("-")[1])

            initial_global_step = global_step
            first_epoch = global_step // num_update_steps_per_epoch

    else:
        initial_global_step = 0

    progress_bar = tqdm(
        range(0, args.max_train_steps),
        initial=initial_global_step,
        desc="Steps",
        # Only show the progress bar once on each machine.
        disable=not accelerator.is_local_main_process,
    )

    for name, module in net_disc.named_modules():
        if "attn" in name:
            module.fused_attn = False

    for epoch in range(first_epoch, args.num_train_epochs):
        net_sr.train()
        net_disc.train()

        for step, batch in enumerate(train_dataloader):
            # Move prompt embeddings to device once (outside accumulation)
            prompt_embeds = prompt_embeds.to(accelerator.device)
            pooled_prompt_embeds = pooled_prompt_embeds.to(accelerator.device)

            with accelerator.accumulate(net_sr, net_disc):
                # Prepare data
                x_src, x_tgt = degradation_proc(config, batch, accelerator.device)

                # --- Generator Forward Pass ---
                with torch.no_grad():
                    x_tgt_latent = encode_images(
                        x_tgt, unwrap_model(net_sr).fix_vae, weight_dtype
                    )

                # Latent space target
                noise = torch.randn_like(
                    x_tgt_latent, device=x_tgt_latent.device, dtype=weight_dtype
                )
                sigma = unwrap_model(net_sr).sigma
                target_latent = sigma * noise + (1 - sigma) * x_tgt_latent

                # Encode source image
                x_src_latent = encode_images(
                    x_src, unwrap_model(net_sr).lora_vae, weight_dtype
                )

                # Generate super-resolved image
                x_tgt_pred = net_sr(
                    x_src_latent,
                    prompt_embeds,
                    pooled_prompt_embeds,
                )

                # --- Calculate All Generator Losses ---
                # 1. Latent loss
                loss_latent = (
                    F.mse_loss(
                        x_src_latent.float(), target_latent.float(), reduction="mean"
                    )
                    * args.lambda_latent
                )

                # 2. Pixel-wise L2 loss
                loss_l2 = (
                    F.mse_loss(x_tgt_pred.float(), x_tgt.float(), reduction="mean")
                    * args.lambda_l2
                )

                # 3. Perceptual (LPIPS) loss
                loss_lpips = (
                    net_lpips(
                        image_to_patches_fold(x_tgt_pred.float()),
                        image_to_patches_fold(x_tgt.float()),
                    ).mean()
                    * args.lambda_lpips
                )

                # 4. GAN generator loss
                lossG = net_disc((x_tgt_pred), for_G=True).mean() * args.lambda_gan

                # Combined generator loss
                total_gen_loss = loss_latent + loss_l2 + loss_lpips + lossG

                # --- Generator Backward ---
                accelerator.backward(total_gen_loss)
                if accelerator.sync_gradients:
                    accelerator.clip_grad_norm_(net_sr_to_optimize, args.max_grad_norm)

                # --- Discriminator Forward Pass ---
                # Detach generated images for discriminator training
                with torch.no_grad():
                    x_tgt_pred_detached = x_tgt_pred.detach()

                # Real images
                lossD_real = net_disc((x_tgt), for_real=True).mean() * args.lambda_gan

                # Fake images
                lossD_fake = (
                    net_disc((x_tgt_pred_detached), for_real=False).mean()
                    * args.lambda_gan
                )

                # Combined discriminator loss
                total_disc_loss = lossD_real + lossD_fake

                # --- Discriminator Backward ---
                accelerator.backward(total_disc_loss)
                if accelerator.sync_gradients:
                    accelerator.clip_grad_norm_(
                        net_disc.parameters(), args.max_grad_norm
                    )

                # --- Update Both Networks ---
                optimizer.step()
                optimizer_disc.step()

                # Update learning rates
                lr_scheduler.step()
                lr_scheduler_disc.step()

                # Zero gradients
                optimizer.zero_grad(set_to_none=args.set_grads_to_none)
                optimizer_disc.zero_grad(set_to_none=args.set_grads_to_none)

            # Checks if the accelerator has performed an optimization step behind the scenes
            if accelerator.sync_gradients:
                if (
                    accelerator.is_main_process
                    and global_step % args.save_img_steps == 0
                ):
                    img_path = os.path.join(args.output_dir, f"img-{global_step}.png")
                    save_imgs = (torch.cat([x_src, x_tgt_pred, x_tgt], dim=0) + 1) / 2
                    save_image(save_imgs.detach(), img_path)
                    logger.info(f"img-{global_step}.png saved!")

                progress_bar.update(1)
                global_step += 1

                if (
                    accelerator.is_main_process
                    or accelerator.distributed_type == DistributedType.DEEPSPEED
                ):
                    if global_step % args.checkpointing_steps == 0:
                        # save_path = os.path.join(
                        #     args.output_dir, f"checkpoint-{global_step}"
                        # )
                        weight_path = os.path.join(
                            args.output_dir, f"weight-{global_step}"
                        )
                        # os.makedirs(save_path, exist_ok=True)
                        os.makedirs(weight_path, exist_ok=True)
                        # accelerator.save_state(save_path)
                        # logger.info(f"Saved state to {save_path}")
                        unwrap_model(net_sr).transformer.save_pretrained(weight_path)
                        unwrap_model(net_sr).lora_vae.encoder.save_pretrained(
                            weight_path
                        )
                        logger.info(f"Saved weight to {weight_path}")

            logs = {
                "loss_latent": loss_latent.detach().item(),
                "lossD_fake": lossD_fake.detach().item(),
                "lossD_real": lossD_real.detach().item(),
                "loss_lpips": loss_lpips.detach().item(),
                "loss_l2": loss_l2.detach().item(),
                "lr": lr_scheduler.get_last_lr()[0],
            }
            progress_bar.set_postfix(**logs)
            accelerator.log(logs, step=global_step)

            if global_step >= args.max_train_steps:
                break

    # Save the lora layers
    accelerator.wait_for_everyone()
    if accelerator.is_main_process:
        # save_path = os.path.join(args.output_dir, f"weight-{global_step}")
        weight_path = os.path.join(args.output_dir, f"weight-{global_step}")
        # os.makedirs(save_path, exist_ok=True)
        os.makedirs(weight_path, exist_ok=True)
        unwrap_model(net_sr).transformer.save_pretrained(weight_path)
        unwrap_model(net_sr).lora_vae.encoder.save_pretrained(weight_path)
        logger.info(f"Saved weight to {weight_path}")

    accelerator.end_training()


if __name__ == "__main__":
    main()
