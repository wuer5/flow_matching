import math
import os
import torch
from tqdm.auto import tqdm
from model import OneModelInf
from peft import PeftModel
from dataloaders.my_dataset import TestDataset
from torchvision.utils import save_image
import torch.nn.functional as F

fixed_prompt_embeds = "./embdds.pt"
sd_path = "/home.old/wzq/sd-turbo"
lora_path = "/home/wzq/code/sd-turbo/v2/weight-40000"
mid_timestep = 195
device = "cuda:0"
prompt_embeds = torch.load(fixed_prompt_embeds, map_location=device, weights_only=True)
net_sr = OneModelInf(
    sd_path=sd_path, lora_path=lora_path, timestep=mid_timestep, device=device
)
NAME = "test_realsr"
train_dataset = TestDataset(test_txt_path=f"{NAME}.txt")
train_dataloader = torch.utils.data.DataLoader(
    train_dataset,
    batch_size=1,
    shuffle=True,
    num_workers=1,
)
progress_bar = tqdm(
    range(0, len(train_dataloader)),
    initial=0,
    desc="Steps",
)
os.makedirs(f"./results_{NAME}", exist_ok=True)
for step, batch in enumerate(train_dataloader):
    im_lr, path = batch
    im_lr = im_lr.cuda()
    im_lr = im_lr.to(memory_format=torch.contiguous_format).float()
    ori_h, ori_w = im_lr.shape[2:]
    im_lr_resize = F.interpolate(
        im_lr,
        size=(ori_h * 4, ori_w * 4),
        mode="bilinear",
        align_corners=False,  # align_corners with this model causes the output to be shifted, presumably due to training without align_corners
    )

    im_lr_resize = im_lr_resize.contiguous()
    im_lr_resize_norm = im_lr_resize * 2 - 1.0
    im_lr_resize_norm = torch.clamp(im_lr_resize_norm, -1.0, 1.0)
    resize_h, resize_w = im_lr_resize_norm.shape[2:]

    pad_h = (math.ceil(resize_h / 64)) * 64 - resize_h
    pad_w = (math.ceil(resize_w / 64)) * 64 - resize_w
    im_lr_resize_norm = F.pad(
        im_lr_resize_norm, pad=(0, pad_w, 0, pad_h), mode="reflect"
    )
    pred = net_sr(im_lr_resize_norm, prompt_embeds)
    # m = torch.cat([lq, pred])
    m = (pred + 1) / 2
    save_image(m, f"results_{NAME}/{os.path.basename(path[0])}")
    progress_bar.update(1)
