import os


def save_filenames_to_txt(directory, output_file):
    with open(output_file, "w", encoding="utf-8") as f:
        for filename in os.listdir(directory):
            f.write(
                "/home/wzq/code/one-step-sd3/datasets/benchmark_drealsr/test_LR/"
                + filename
                + "\n"
            )


# 使用示例
directory_path = "/home/wzq/code/one-step-sd3/datasets/benchmark_drealsr/test_LR"  # 替换为你的目录路径
output_txt = "test_drealsr.txt"  # 输出文件名
save_filenames_to_txt(directory_path, output_txt)
