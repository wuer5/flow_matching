import torch
from torchvision.utils import save_image

from model import get_unet_model

sample_shape = (28, 1, 28, 28)
DEVICE = 'cuda:0'
t_steps = 100
model = get_unet_model(img_size=sample_shape[-1], in_channels=sample_shape[1])
state_dict = torch.load('best_model.pth')
model.load_state_dict(state_dict['model_state_dict'])
model.to('cuda')
model.eval()
from rectified_flow import RectifiedFlow

rf = RectifiedFlow()
with torch.no_grad():
    results = rf.sample(model, t_steps, sample_shape, DEVICE)
    save_image(results, 'output.jpg', nrow=7)  # nrow=7表示每行显示7张图片
    print('Saved output.jpg')