#!/usr/bin/env python
# coding=utf-8
# Copyright 2025 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and

import argparse
import logging
import math
import os
from pathlib import Path
from omegaconf import OmegaConf
import torch
import transformers
from accelerate import Accelerator, DistributedType
from accelerate.logging import get_logger
from accelerate.utils import (
    ProjectConfiguration,
    set_seed,
)
from tqdm.auto import tqdm
from transformers import AutoTokenizer, CLIPTextModel, PretrainedConfig
from torchvision.utils import save_image
import diffusers
from diffusers import (
    AutoencoderKL,
)
from diffusers.optimization import get_scheduler
from diffusers.training_utils import (
    free_memory,
)
from diffusers.utils.torch_utils import is_compiled_module
import torch.nn.functional as F
import warnings
from dataloaders.my_dataset import PairedDataset, degradation_proc
from diffusers.utils.import_utils import is_xformers_available
from patch_util import image_to_patches_fold
from peft import LoraConfig, PeftModel

warnings.filterwarnings("ignore")


logger = get_logger(__name__)


def set_vae_encoder_lora(vae_encoder, rank):
    target_modules = [
        "conv1",
        "conv2",
        "conv_in",
        "conv_shortcut",
        "conv",
        "conv_out",
        "to_k",
        "to_q",
        "to_v",
        "to_out.0",
    ]

    vae_encoder_lora_config = LoraConfig(
        r=rank,
        target_modules=target_modules,
        init_lora_weights="gaussian",
    )
    vae_encoder = PeftModel(
        model=vae_encoder,
        peft_config=vae_encoder_lora_config,
        adapter_name="vae_encoder_lora_adapter",
    )
    vae_encoder.print_trainable_parameters()
    return vae_encoder


def parse_args():
    parser = argparse.ArgumentParser(description="Simple example of a training script.")
    parser.add_argument(
        "--config",
        type=str,
        default="cfg.yml",
        help="path to config",
    )
    args = parser.parse_args()

    return args.config


def main():
    args = OmegaConf.load(parse_args())
    config = OmegaConf.load(args.degra_cfg)
    logging_dir = Path(args.output_dir, args.logging_dir)

    accelerator_project_config = ProjectConfiguration(
        project_dir=args.output_dir, logging_dir=logging_dir
    )
    accelerator = Accelerator(
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        mixed_precision=args.mixed_precision,
        project_config=accelerator_project_config,
    )

    # Disable AMP for MPS.
    if torch.backends.mps.is_available():
        accelerator.native_amp = False

    # Make one log on every process with the configuration for debugging.
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO,
    )
    logger.info(accelerator.state, main_process_only=False)
    if accelerator.is_local_main_process:
        transformers.utils.logging.set_verbosity_warning()
        diffusers.utils.logging.set_verbosity_info()
    else:
        transformers.utils.logging.set_verbosity_error()
        diffusers.utils.logging.set_verbosity_error()

    # If passed along, set the training seed now.
    if args.seed is not None:
        set_seed(args.seed)

    # Handle the repository creation
    if accelerator.is_main_process:
        if args.output_dir is not None:
            os.makedirs(args.output_dir, exist_ok=True)
            OmegaConf.save(args, os.path.join(args.output_dir, "cfg.yml"))

    # For mixed precision training we cast all non-trainable weights (vae, non-lora text_encoder and non-lora transformer) to half-precision
    # as these weights are only used for inference, keeping weights in full precision is not required.
    weight_dtype = torch.float32
    if accelerator.mixed_precision == "fp16":
        weight_dtype = torch.float16
    elif accelerator.mixed_precision == "bf16":
        weight_dtype = torch.bfloat16

    from model import OneModel
    import copy

    vae = AutoencoderKL.from_pretrained(args.sd_path, subfolder="vae")
    lora_vae = copy.deepcopy(vae)
    del lora_vae.decoder
    free_memory()
    vae.requires_grad_(False)
    lora_vae.requires_grad_(False)
    lora_vae.encoder = set_vae_encoder_lora(lora_vae.encoder, args.vae_rank)
    vae.to(accelerator.device)
    lora_vae.to(accelerator.device)
    net_sr = OneModel(
        args.sd_path,
        vae=vae,
        timestep=args.mid_timestep,
        unet_rank=args.unet_rank,
        device=accelerator.device,
    )

    # # init RAM for text prompt extractor
    # from ram.models.ram_lora import ram
    # from ram import inference_ram as inference
    # from torchvision import transforms

    # ram_transforms = transforms.Compose(
    #     [
    #         transforms.Resize((384, 384)),
    #         transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    #     ]
    # )
    # RAM = ram(
    #     pretrained="src/ram_pretrain_model/ram_swin_large_14m.pth",
    #     pretrained_condition=None,
    #     image_size=384,
    #     vit="swin_l",
    # )
    # RAM.eval()
    # RAM.to("cuda", dtype=torch.float16)

    if args.enable_xformers_memory_efficient_attention:
        if is_xformers_available():
            net_sr.unet.enable_xformers_memory_efficient_attention()
        else:
            raise ValueError(
                "xformers is not available, please install it by running `pip install xformers`"
            )

    import vision_aided_loss

    net_disc = vision_aided_loss.Discriminator(
        cv_type="dino",
        output_type="conv_multi_level",
        loss_type=args.gan_loss_type,
        device=accelerator.device,
    )
    import lpips

    net_lpips = lpips.LPIPS(net="vgg").to(accelerator.device)
    net_lpips.requires_grad_(False)

    net_disc = net_disc.to(accelerator.device)
    net_disc.requires_grad_(True)
    net_disc.cv_ensemble.requires_grad_(False)

    if args.gradient_checkpointing:
        net_sr.transformer.enable_gradient_checkpointing()

    def unwrap_model(model):
        model = accelerator.unwrap_model(model)
        model = model._orig_mod if is_compiled_module(model) else model
        return model

    # Enable TF32 for faster training on Ampere GPUs,
    # cf https://pytorch.org/docs/stable/notes/cuda.html#tensorfloat-32-tf32-on-ampere-devices
    if args.allow_tf32 and torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True

    logger.info(
        f"Total vae encoder training parameters: {sum([p.numel() for p in lora_vae.parameters() if p.requires_grad]) / 1000000} M"
    )
    logger.info(
        f"Total net_sr training parameters: {sum([p.numel() for p in net_sr.parameters() if p.requires_grad]) / 1000000} M"
    )
    logger.info(
        f"Total net_disc training parameters: {sum([p.numel() for p in net_disc.parameters() if p.requires_grad]) / 1000000} M"
    )
    lora_vae_opt = list(filter(lambda p: p.requires_grad, lora_vae.parameters()))
    net_sr_opt = list(filter(lambda p: p.requires_grad, net_sr.parameters()))
    net_disc_opt = list(filter(lambda p: p.requires_grad, net_disc.parameters()))

    if args.use_8bit_adam:
        try:
            import bitsandbytes as bnb
        except ImportError:
            raise ImportError(
                "To use 8-bit Adam, please install the bitsandbytes library: `pip install bitsandbytes`."
            )

        optimizer_class = bnb.optim.AdamW8bit
    else:
        optimizer_class = torch.optim.AdamW

    optimizer_vae = optimizer_class(
        lora_vae_opt,
        lr=args.learning_rate,
        betas=(args.adam_beta1, args.adam_beta2),
        weight_decay=args.adam_weight_decay,
        eps=args.adam_epsilon,
    )

    optimizer_sr = optimizer_class(
        net_sr_opt,
        lr=args.learning_rate,
        betas=(args.adam_beta1, args.adam_beta2),
        weight_decay=args.adam_weight_decay,
        eps=args.adam_epsilon,
    )

    optimizer_disc = optimizer_class(
        net_disc_opt,
        lr=args.learning_rate,
        betas=(args.adam_beta1, args.adam_beta2),
        weight_decay=args.adam_weight_decay,
        eps=args.adam_epsilon,
    )

    train_dataset = PairedDataset(config.train)
    train_dataloader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=args.train_batch_size,
        shuffle=True,
        num_workers=args.dataloader_num_workers,
    )

    # Scheduler and math around the number of training steps.
    overrode_max_train_steps = False
    num_update_steps_per_epoch = math.ceil(
        len(train_dataloader) / args.gradient_accumulation_steps
    )
    if args.max_train_steps is None:
        args.max_train_steps = args.num_train_epochs * num_update_steps_per_epoch
        overrode_max_train_steps = True

    lr_scheduler_vae = get_scheduler(
        args.lr_scheduler,
        optimizer=optimizer_vae,
        num_warmup_steps=args.lr_warmup_steps * accelerator.num_processes,
        num_training_steps=args.max_train_steps * accelerator.num_processes,
        num_cycles=args.lr_num_cycles,
        power=args.lr_power,
    )

    lr_scheduler_sr = get_scheduler(
        args.lr_scheduler,
        optimizer=optimizer_sr,
        num_warmup_steps=args.lr_warmup_steps * accelerator.num_processes,
        num_training_steps=args.max_train_steps * accelerator.num_processes,
        num_cycles=args.lr_num_cycles,
        power=args.lr_power,
    )

    lr_scheduler_disc = get_scheduler(
        args.lr_scheduler,
        optimizer=optimizer_disc,
        num_warmup_steps=args.lr_warmup_steps * accelerator.num_processes,
        num_training_steps=args.max_train_steps * accelerator.num_processes,
        num_cycles=args.lr_num_cycles,
        power=args.lr_power,
    )

    (
        lora_vae,
        net_sr,
        net_disc,
        optimizer_vae,
        optimizer_sr,
        optimizer_disc,
        train_dataloader,
        lr_scheduler_vae,
        lr_scheduler_sr,
        lr_scheduler_disc,
    ) = accelerator.prepare(
        lora_vae,
        net_sr,
        net_disc,
        optimizer_vae,
        optimizer_sr,
        optimizer_disc,
        train_dataloader,
        lr_scheduler_vae,
        lr_scheduler_sr,
        lr_scheduler_disc,
    )

    # We need to recalculate our total training steps as the size of the training dataloader may have changed.
    num_update_steps_per_epoch = math.ceil(
        len(train_dataloader) / args.gradient_accumulation_steps
    )
    if overrode_max_train_steps:
        args.max_train_steps = args.num_train_epochs * num_update_steps_per_epoch
    # Afterwards we recalculate our number of training epochs
    args.num_train_epochs = math.ceil(args.max_train_steps / num_update_steps_per_epoch)

    # Train!
    total_batch_size = (
        args.train_batch_size
        * accelerator.num_processes
        * args.gradient_accumulation_steps
    )

    logger.info("***** Running training *****")
    logger.info(f"  Num examples = {len(train_dataset)}")
    logger.info(f"  Num batches each epoch = {len(train_dataloader)}")
    logger.info(f"  Num Epochs = {args.num_train_epochs}")
    logger.info(f"  Instantaneous batch size per device = {args.train_batch_size}")
    logger.info(
        f"  Total train batch size (w. parallel, distributed & accumulation) = {total_batch_size}"
    )
    logger.info(f"  Gradient Accumulation steps = {args.gradient_accumulation_steps}")
    logger.info(f"  Total optimization steps = {args.max_train_steps}")
    global_step = 0
    first_epoch = 0

    # Potentially load in the weights and states from a previous save
    if args.resume_from_checkpoint:
        if args.resume_from_checkpoint != "latest":
            path = os.path.basename(args.resume_from_checkpoint)
        else:
            # Get the mos recent checkpoint
            dirs = os.listdir(args.output_dir)
            dirs = [d for d in dirs if d.startswith("checkpoint")]
            dirs = sorted(dirs, key=lambda x: int(x.split("-")[1]))
            path = dirs[-1] if len(dirs) > 0 else None

        if path is None:
            accelerator.print(
                f"Checkpoint '{args.resume_from_checkpoint}' does not exist. Starting a new training run."
            )
            args.resume_from_checkpoint = None
            initial_global_step = 0
        else:
            accelerator.print(f"Resuming from checkpoint {path}")
            accelerator.load_state(os.path.join(args.output_dir, path))
            global_step = int(path.split("-")[1])

            initial_global_step = global_step
            first_epoch = global_step // num_update_steps_per_epoch

    else:
        initial_global_step = 0

    progress_bar = tqdm(
        range(0, args.max_train_steps),
        initial=initial_global_step,
        desc="Steps",
        # Only show the progress bar once on each machine.
        disable=not accelerator.is_local_main_process,
    )

    for name, module in net_disc.named_modules():
        if "attn" in name:
            module.fused_attn = False

    if not args.fixed_prompt_embeds:
        tokenizer = AutoTokenizer.from_pretrained(args.sd_path, subfolder="tokenizer")
        text_encoder = CLIPTextModel.from_pretrained(
            args.sd_path, subfolder="text_encoder"
        ).to(accelerator.device)

        def encode_prompt(prompt_batch):
            """Encode text prompts into embeddings."""
            with torch.no_grad():
                prompt_embeds = [
                    text_encoder(
                        tokenizer(
                            caption,
                            max_length=tokenizer.model_max_length,
                            padding="max_length",
                            truncation=True,
                            return_tensors="pt",
                        ).input_ids.to(text_encoder.device)
                    )[0]
                    for caption in prompt_batch
                ]
            return torch.concat(prompt_embeds, dim=0)

        prompt_embedds = encode_prompt(args.instance_prompt)
        torch.save(prompt_embedds, "embdds.pt")
    else:
        prompt_embedds = torch.load("embdds.pt", map_location=accelerator.device)

    for epoch in range(first_epoch, args.num_train_epochs):
        lora_vae.train()
        net_sr.train()
        net_disc.train()
        for step, batch in enumerate(train_dataloader):
            with accelerator.accumulate(*[lora_vae, net_sr, net_disc]):
                # Prepare data
                x_src, x_tgt = degradation_proc(config, batch, accelerator.device)

                with torch.no_grad():
                    x_tgt_latent = (
                        vae.encode(x_tgt).latent_dist.sample()
                        * vae.config.scaling_factor
                    )

                noise = torch.randn_like(x_tgt_latent, device=x_tgt_latent.device)
                t = torch.tensor(
                    [args.mid_timestep], dtype=torch.long, device=x_tgt_latent.device
                )
                target_latent = unwrap_model(net_sr).scheduler.add_noise(
                    x_tgt_latent, noise, t
                )
                # Encode source image
                x_src_latent = (
                    unwrap_model(lora_vae).encode(x_src).latent_dist.sample()
                    * unwrap_model(lora_vae).config.scaling_factor
                )

                loss_latent = (
                    F.mse_loss(
                        x_src_latent.float(), target_latent.float(), reduction="mean"
                    )
                    * args.lambda_latent
                )

                accelerator.backward(loss_latent)
                if accelerator.sync_gradients:
                    accelerator.clip_grad_norm_(lora_vae_opt, args.max_grad_norm)

                optimizer_vae.step()
                lr_scheduler_vae.step()
                optimizer_vae.zero_grad()

                x_tgt_pred = net_sr(x_src_latent.detach(), prompt_embedds)
                loss_l2 = (
                    F.mse_loss(x_tgt_pred.float(), x_tgt.float(), reduction="mean")
                    * args.lambda_l2
                )

                loss_lpips = (
                    net_lpips(
                        image_to_patches_fold(x_tgt_pred.float()),
                        image_to_patches_fold(x_tgt.float()),
                    ).mean()
                    * args.lambda_lpips
                )

                lossG = (
                    net_disc(image_to_patches_fold(x_tgt_pred), for_G=True).mean()
                    * args.lambda_gan
                )

                total_gen_loss = loss_l2 + loss_lpips + lossG

                accelerator.backward(total_gen_loss)
                if accelerator.sync_gradients:
                    accelerator.clip_grad_norm_(net_sr_opt, args.max_grad_norm)

                optimizer_sr.step()
                lr_scheduler_sr.step()
                optimizer_sr.zero_grad()

                # Real images
                lossD_real = (
                    net_disc(image_to_patches_fold(x_tgt), for_real=True).mean()
                    * args.lambda_gan
                )

                # Fake images
                lossD_fake = (
                    net_disc(
                        image_to_patches_fold(x_tgt_pred.detach()), for_real=False
                    ).mean()
                    * args.lambda_gan
                )

                total_disc_loss = lossD_real + lossD_fake

                accelerator.backward(total_disc_loss)
                if accelerator.sync_gradients:
                    accelerator.clip_grad_norm_(net_disc_opt, args.max_grad_norm)

                optimizer_disc.step()
                lr_scheduler_disc.step()
                optimizer_disc.zero_grad()

            # Checks if the accelerator has performed an optimization step behind the scenes
            if accelerator.sync_gradients:
                if (
                    accelerator.is_main_process
                    and global_step % args.save_img_steps == 0
                ):
                    img_path = os.path.join(args.output_dir, f"img-{global_step}.png")
                    save_imgs = (torch.cat([x_src, x_tgt_pred, x_tgt], dim=0) + 1) / 2
                    save_image(save_imgs.detach(), img_path)
                    logger.info(f"img-{global_step}.png saved!")

                progress_bar.update(1)
                global_step += 1

                if (
                    accelerator.is_main_process
                    or accelerator.distributed_type == DistributedType.DEEPSPEED
                ):
                    if global_step % args.checkpointing_steps == 0:
                        # save_path = os.path.join(
                        #     args.output_dir, f"checkpoint-{global_step}"
                        # )
                        weight_path = os.path.join(
                            args.output_dir, f"weight-{global_step}"
                        )
                        # os.makedirs(save_path, exist_ok=True)
                        os.makedirs(weight_path, exist_ok=True)
                        # accelerator.save_state(save_path)
                        # logger.info(f"Saved state to {save_path}")
                        unwrap_model(net_sr).unet.save_pretrained(weight_path)
                        unwrap_model(lora_vae).encoder.save_pretrained(weight_path)
                        logger.info(f"Saved weight to {weight_path}")

            logs = {
                "loss_latent": loss_latent.detach().item(),
                "lossD_fake": lossD_fake.detach().item(),
                "lossD_real": lossD_real.detach().item(),
                "loss_lpips": loss_lpips.detach().item(),
                "loss_l2": loss_l2.detach().item(),
                "lr": lr_scheduler_sr.get_last_lr()[0],
            }
            progress_bar.set_postfix(**logs)
            accelerator.log(logs, step=global_step)

            if global_step >= args.max_train_steps:
                break

    # Save the lora layers
    accelerator.wait_for_everyone()
    if accelerator.is_main_process:
        # save_path = os.path.join(args.output_dir, f"weight-{global_step}")
        weight_path = os.path.join(args.output_dir, f"weight-{global_step}")
        # os.makedirs(save_path, exist_ok=True)
        os.makedirs(weight_path, exist_ok=True)
        unwrap_model(net_sr).unet.save_pretrained(weight_path)
        unwrap_model(lora_vae).encoder.save_pretrained(weight_path)
        logger.info(f"Saved weight to {weight_path}")

    accelerator.end_training()


if __name__ == "__main__":
    main()
