import torch
import torch.nn.functional as F


def image_to_patches_fold(image_tensor, patch_size=224):
    # 使用 unfold 提取 patches
    if len(image_tensor) == 3:
        image_tensor = image_tensor.unsqueeze(0)
    _, C, H, W = image_tensor.shape
    assert H == W
    if H % patch_size == 0:
        stride = patch_size
    else:
        N = int((H / patch_size)) + 1
        stride = patch_size - (N * patch_size - H) // (N - 1)
    patches = F.unfold(
        image_tensor, kernel_size=patch_size, stride=stride
    )  # (1, C*patch_size*patch_size, num_patches)
    # 调整形状
    patches = patches.permute(0, 2, 1).view(
        -1, C, patch_size, patch_size
    )  # (num_patches, C, patch_size, patch_size)

    return patches


# image = torch.randn(3, 1024, 1024)
# patches = image_to_patches_fold(image, patch_size=224)
# print(patches.shape)  # torch.Size([25, 3, 224, 224])
