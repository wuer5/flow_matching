from diffusers import DiffusionPipeline, DDPMScheduler

# pipe = DiffusionPipeline.from_pretrained("/home.old/wzq/sd-turbo").to("cuda")

# prompt = "Astronaut in a jungle, cold color palette, muted colors, detailed, 8k"
# image = pipe(prompt).images[0]
noise_scheduler_1step = DDPMScheduler.from_pretrained(
    "/home.old/wzq/sd-turbo", subfolder="scheduler"
)
alpha_t = noise_scheduler_1step.alphas_cumprod[195]
print((1 - alpha_t).sqrt())
print((alpha_t).sqrt())
