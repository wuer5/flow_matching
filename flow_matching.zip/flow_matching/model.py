from diffusers.models import UNet2DModel


def get_unet_model(img_size, in_channels=3):
    model = UNet2DModel(
        sample_size=img_size,  # 图像分辨率
        in_channels=in_channels,  # 输入通道数
        out_channels=in_channels,  # 输出通道数
        block_out_channels=(224 // 8, 448 // 8, 672 // 8, 896 // 8),
        norm_num_groups=32 // 8
    )
    return model

# model = get_unet_model(28, 1)
# x = torch.randn(1, 1, 28, 28)
# y = model(x, 0.2)
# print(y.shape)
