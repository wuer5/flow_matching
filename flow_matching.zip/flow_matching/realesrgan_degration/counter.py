import os


def count_files_in_directory(directory):
    files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]
    return len(files)


if __name__ == '__main__':
    for i in range(70):
        if 0 <= i <= 9:
            print(count_files_in_directory(f'./lq_0000{i}'))
        else:
            print(count_files_in_directory(f'./lq_000{i}'))
