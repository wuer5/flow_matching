import os
import cv2
from tqdm import tqdm


def concat_images_from_folders(folder1, folder2, output_folder, horizontal=True):
    """
    将两个文件夹中文件名相同的图片并列拼接起来

    参数:
        folder1: 第一个图片文件夹路径
        folder2: 第二个图片文件夹路径
        output_folder: 输出文件夹路径
        horizontal: 是否水平拼接(True为水平，False为垂直)
    """
    # 确保输出文件夹存在
    os.makedirs(output_folder, exist_ok=True)

    # 获取两个文件夹中的文件列表
    files1 = set(os.listdir(folder1))
    files2 = set(os.listdir(folder2))

    # 找出两个文件夹中都存在的文件
    common_files = files1 & files2

    # 筛选出图片文件(根据扩展名)
    image_extensions = {".jpg", ".jpeg", ".png", ".bmp", ".tif"}
    common_images = [
        f for f in common_files if os.path.splitext(f)[1].lower() in image_extensions
    ]

    print(f"找到 {len(common_images)} 张共同图片")

    # 处理每张图片
    for filename in tqdm(common_images, desc="处理图片"):
        # 读取两张图片
        img1_path = os.path.join(folder1, filename)
        img2_path = os.path.join(folder2, filename)

        img1 = cv2.imread(img1_path)
        img2 = cv2.imread(img2_path)

        if img1 is None or img2 is None:
            print(f"无法读取图片: {filename}")
            continue

        # 确保两张图片高度相同(水平拼接时)
        if horizontal:
            if img1.shape[0] != img2.shape[0]:
                # 调整第二张图片高度与第一张相同
                img2 = cv2.resize(
                    img2,
                    (int(img2.shape[1] * img1.shape[0] / img2.shape[0]), img1.shape[0]),
                )
        else:  # 垂直拼接时确保宽度相同
            if img1.shape[1] != img2.shape[1]:
                # 调整第二张图片宽度与第一张相同
                img2 = cv2.resize(
                    img2,
                    (img1.shape[1], int(img2.shape[0] * img1.shape[1] / img2.shape[1])),
                )

        # 拼接图片
        if horizontal:
            concatenated = cv2.hconcat([img1, img2])
        else:
            concatenated = cv2.vconcat([img1, img2])

        # 保存结果
        output_path = os.path.join(output_folder, filename)
        cv2.imwrite(output_path, concatenated)


# 使用示例
if __name__ == "__main__":
    folder1 = "/home/wzq/code/one-step-sd3/results_realsr"  # 替换为第一个文件夹路径
    folder2 = "/home/wzq/code/one-step-sd3/datasets/benchmark_realsr/results_osediff"  # 替换为第二个文件夹路径
    output_folder = "./cmp"  # 替换为输出文件夹路径

    # 水平拼接
    concat_images_from_folders(folder1, folder2, output_folder, horizontal=True)

    # 或者垂直拼接
    # concat_images_from_folders(folder1, folder2, output_folder, horizontal=False)
