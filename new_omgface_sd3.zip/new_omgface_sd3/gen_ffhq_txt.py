# import os


# def save_image_paths_to_txt(folder_path, output_txt):
#     # 支持的图片扩展名
#     image_extensions = [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp"]

#     # 获取文件夹中所有图片的绝对路径
#     image_paths = []
#     for root, dirs, files in os.walk(folder_path):
#         for file in files:
#             if any(file.lower().endswith(ext) for ext in image_extensions):
#                 image_paths.append(os.path.abspath(os.path.join(root, file)))

#     # 将路径写入txt文件
#     with open(output_txt, "w") as f:
#         for path in image_paths:
#             f.write(path + "\n")

#     print(f"共找到 {len(image_paths)} 张图片，路径已保存到 {output_txt}")


# # 使用示例
# folder_path = "/DataDisk1/wzq/datasets/FFHQ1024/FFHQ-1024-2"  # 替换为你的文件夹路径
# output_txt = "ffhq_2.txt"  # 输出的txt文件名

# save_image_paths_to_txt(folder_path, output_txt)
with open("ffhq_1.txt", "r") as f:
    ps1 = [l.strip() for l in f]
with open("ffhq_2.txt", "r") as f:
    ps2 = [l.strip() for l in f]

ps1.extend(ps2)
ps1.sort()
with open("ffhq70000.txt", "w") as f:
    for p in ps1:
        f.write(p + "\n")
